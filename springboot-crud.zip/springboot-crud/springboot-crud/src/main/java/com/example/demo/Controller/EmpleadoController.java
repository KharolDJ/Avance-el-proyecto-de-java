package com.example.demo.Controller;

import com.example.demo.Entity.MenuItem;
import com.example.demo.Service.MenuService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/empleado")
public class EmpleadoController {

    private final MenuService menuService;

    public EmpleadoController(MenuService menuService) {
        this.menuService = menuService;
    }

    @GetMapping("")
    public String verMenu(Model model) {
        List<MenuItem> lista = menuService.listAll();
        model.addAttribute("menuItems", lista);
        return "empleado";
    }

    @PostMapping("/save")
    public String guardar(@ModelAttribute MenuItem item) {
        menuService.save(item);
        return "redirect:/empleado";
    }

    @GetMapping("/delete/{id}")
    public String eliminar(@PathVariable Long id) {
        menuService.delete(id);
        return "redirect:/empleado";
    }
}
