package com.example.demo.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.MenuItem;


public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {}