package com.example.demo.Controller;

import com.example.demo.Entity.MenuItem;
import com.example.demo.Service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private MenuService menuService;

    // Página principal
    @GetMapping("/")
    public String home() {
        return "index";
    }

    // Vista del cliente (solo lectura)
    @GetMapping("/cliente")
    public String cliente(Model model) {
        List<MenuItem> menu = menuService.listAll();
        model.addAttribute("menu", menu);
        return "cliente";
    }
}
