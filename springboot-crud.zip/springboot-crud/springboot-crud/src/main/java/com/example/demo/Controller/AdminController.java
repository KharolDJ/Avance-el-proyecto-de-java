package com.example.demo.Controller;

import com.example.demo.Entity.Empleado;
import com.example.demo.Service.EmpleadoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final EmpleadoService empleadoService;

    public AdminController(EmpleadoService empleadoService) {
        this.empleadoService = empleadoService;
    }

    // Mostrar lista de empleados
    @GetMapping("")
    public String listarEmpleados(Model model) {
        List<Empleado> lista = empleadoService.listAll();
        model.addAttribute("empleados", lista);
        return "admin";
    }

    // Guardar un nuevo empleado
    @PostMapping("/save")
    public String guardarEmpleado(@ModelAttribute Empleado empleado) {
        empleadoService.save(empleado);
        return "redirect:/admin";
    }

    // Eliminar un empleado
    @GetMapping("/delete/{id}")
    public String eliminarEmpleado(@PathVariable Long id) {
        empleadoService.delete(id);
        return "redirect:/admin";
    }

    // Editar empleado (mostrar datos en formulario)
    @GetMapping("/edit/{id}")
    public String editarEmpleado(@PathVariable Long id, Model model) {
        Empleado empleado = empleadoService.getById(id);
        model.addAttribute("empleado", empleado);
        return "editar_empleado"; // vista separada opcional
    }

    // Actualizar empleado (desde formulario de edición)
    @PostMapping("/update")
    public String actualizarEmpleado(@ModelAttribute Empleado empleado) {
        empleadoService.save(empleado);
        return "redirect:/admin";
    }
}
