package com.example.demo.Service;

import com.example.demo.Entity.Empleado;
import com.example.demo.Repository.EmpleadoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmpleadoService {

    private final EmpleadoRepository empleadoRepository;

    public EmpleadoService(EmpleadoRepository empleadoRepository) {
        this.empleadoRepository = empleadoRepository;
    }

    public List<Empleado> listAll() {
        return empleadoRepository.findAll();
    }

    public void save(Empleado empleado) {
        empleadoRepository.save(empleado);
    }

    public void delete(Long id) {
        empleadoRepository.deleteById(id);
    }

    public Empleado getById(Long id) {
        return empleadoRepository.findById(id).orElse(null);
    }
}
