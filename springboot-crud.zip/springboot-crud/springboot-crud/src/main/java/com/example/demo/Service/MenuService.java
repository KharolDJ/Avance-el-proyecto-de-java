package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Entity.MenuItem;
import com.example.demo.Repository.MenuItemRepository;

@Service
@Transactional(readOnly = true)
public class MenuService {

    private final MenuItemRepository repo;

    public MenuService(MenuItemRepository repo) {
        this.repo = repo;
    }

    public List<MenuItem> listAll() {
        return repo.findAll();
    }

    public Optional<MenuItem> get(Long id) {
        return repo.findById(id);
    }

    @Transactional
    public MenuItem save(MenuItem menuItem) {
        return repo.save(menuItem);
    }

    @Transactional
    public void delete(Long id) {
        repo.deleteById(id);
    }
}
